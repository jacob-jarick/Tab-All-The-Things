﻿=== RAIMBOW Cursor Set ===

By: JOSEHICTIMOSQUI (http://www.rw-designer.com/user/68507)

Download: http://www.rw-designer.com/cursor-set/raimbow

Author's description:

RAIMBOW AND ARCOIRIS
100% REAL NO FAKE
si me falta un cursor avisenme(porfa)
  los tengo todos solo que no los he subido :v

==========

License: Creative Commons - Attribution + Noncommercial

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.
* Noncommercial - You may not use this work for commercial purposes.